if (!customElements.get('expert-video')) {
  customElements.whenDefined('modal-dialog').then(() => {

    class expertVideo extends Modal {
      constructor() {
        super();
        this.sectionId = this.dataset.sectionId;
        if (Shopify.designMode) {
          document.addEventListener('shopify:section:select', (evt) => {
            if (evt.target === this.closest('.shopify-section')) this.open();
          });

          document.addEventListener('shopify:section:deselect', this.close.bind(this));
        }
        this.openButton = document.getElementById('expert-guide-cta');
        this.openButton.addEventListener('click', () => this.open());
      }
    };

    customElements.define('expert-video', expertVideo);
  });
}