class ComparePage extends HTMLElement {
  constructor() {
    super();

    const rawData = sessionStorage['compare-products'];

    if (!rawData) return;

    this.$compareList = this.querySelector('.compare-page__list');
    this.$backBtn = this.querySelector('.js-back-btn');
    this.$clearAllBtn = this.querySelector('.js-clear-all-btn');
    this.items = JSON.parse(rawData);
    this.metafieldIdentifiers = window.comparePageMetafields;
    this.init();
    this.eventHandlers();
  }

  renderProductImage({ product }) {
    const { title, featuredImage } = product;
    const url = featuredImage?.url || window.theme.settings.defaultProductImage;
    const alt = featuredImage?.altText || title;

    return `
      <div class="compare-page__img-wrapper">
        <div class="img-ar img-ar--cover" style="--aspect-ratio: 1.0">
          <img src="${url}&amp;width=1200"
            alt="${alt}"
            srcset="${url}&amp;width=340 340w,
              ${url}&amp;width=480 480w,
              ${url}&amp;width=740 740w,
              ${url}&amp;width=980 980w,
              ${url}&amp;width=1200 1200w,
              ${url}&amp;width=1200 1200w"
            width="1200"
            height="1200"
            loading="eager"
            sizes="(min-width: 1600px) 533px,(min-width: 768px) 33vw,50vw"
            class="theme-img">
        </div>
        <button type="button"
          class="compare-page__remove js-clear-target-btn"
          data-target-id="${product.id}">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M4.5 4.5L19.5 19.5M4.5 19.5L19.5 4.5" stroke="currentColor" stroke-width="2"></path>
          </svg>
        </button>
      </div>
    `;
  }

  renderProductGender({ product }) {
    const { metafields } = product;
    const gender = metafields.find((metafield) => (
      metafield?.namespace === 'custom' && metafield?.key === 'gender'
    ));

    return gender ? `<div class="product-block__gender text-small">
      ${gender.value}
    </div>` : '';
  }

  renderProductTitle({ product }) {
    const { title } = product;

    return `
      <div class="product-block__title text-body">
        ${title}
      </div>
    `;
  }

  renderYotpoRatingsWidget({ product }) {
    const { yotpoInstanceId } = window.theme.settings;
    const { id } = product;

    return `
      <div class="yotpo-widget-instance"
        data-yotpo-instance-id="${yotpoInstanceId}"
        data-yotpo-product-id="${id.replace('gid://shopify/Product/', '')}"
        data-yotpo-section-id="${this.parentElement.id}"
      ></div>
    `;
  }

  renderProductPrice({ product }) {
    const { priceRange: { minVariantPrice, maxVariantPrice }, variants: { edges: variants } } = product;
    const currentVariant = variants.find(({ node: { availableForSale } }) => (availableForSale));

    if (!currentVariant) return '';

    const { node: { availableForSale, price, compareAtPrice } } = currentVariant;
    const hasComparePrice = parseFloat(compareAtPrice?.amount) > parseFloat(price?.amount);
    const priceClasses = [
      hasComparePrice ? 'price--on-sale': '',
      availableForSale ? 'price--sold-out': '',
    ].join(' ');

    return `
      <div class="product-price--block product-price">
        <div class="price--custom price ${priceClasses}">
          <div class="price__default">
            ${parseFloat(maxVariantPrice.amount) > parseFloat(minVariantPrice.amount) ? `
              <span class="price__from">
                ${window.comparePageTranslations.from}
              </span>
            ` : ''}
            <span class="price__current text-body ${hasComparePrice ? 'sale-price' : ''}">
              $${price.amount}
            </span>
            ${hasComparePrice ? `
              <span class="price__was text-body">
                ${compareAtPrice.amount}
              </span>
            ` : ''}
          </div>
        </div>
      </div>
    `
  }

  renderViewBtn({ product }) {
    return `
      <div class="compare-page__view-btn">
        <a href="/products/${product.handle}" class="btn btn--primary">
          ${window.comparePageTranslations.view}
        </a>
      </div>
    `;
  }

  renderOptionsVendor({ product }) {
    const { vendor } = product;

    return `
      <p>${vendor}</p>
    `;
  }

  renderOptions({ name, values, variants }) {
    const availableOptions = variants
      .filter(({ node: { availableForSale } }) => (availableForSale))
      .map(({ node: { selectedOptions }}) => {
        const { value: selectedOptionValue } = selectedOptions
          .find(({ name: selectedOptionName }) => (selectedOptionName === name))
        ;

        return selectedOptionValue;
      })
    ;
    const availableOptionsUnique = [...new Set(availableOptions)];

    return values.map((value) => {
      const isAvailable = availableOptionsUnique
        .find((availableOption) => (availableOption === value))
      ;

      return `
        <span class="product-block-options__item ${isAvailable ? '' : 'is-unavailable'}"
          data-option-name="${value}">
          <span class="product-block-options__item__text">
            ${value}
          </span>
        </span>
      `;
    }).join('');
  }

  renderSwatches({ name, values, variants }) {
    return values.map((value) => {
      const variant = variants.find((variant) => {
        const { node: { selectedOptions } } = variant;
        const optionFound = selectedOptions.find((selectedOption) => {
          const { name: variantOptionName, value: variantOptionValue } = selectedOption;

          return name === variantOptionName && value === variantOptionValue;
        });

        return optionFound;
      });

      if (!variant) return '';

      const { node: { title, image } } = variant;
      const url = image?.url || window.theme.settings.defaultProductImage;
      const alt = image?.altText || title;

      return `
        <span class="product-block-options__item" data-option-name="${value}">
          <span class="product-block-options__item__text">
            ${value}
          </span>
          <div class="img-ar img-ar--cover" style="--aspect-ratio: 1.0">
            <img src="${url}&amp;width=1200"
              alt="${alt}"
              srcset="${url}&amp;width=36 36w,${url}&amp;width=72 72w"
              width="1200"
              height="1200"
              loading="lazy"
              sizes="36px"
              class="theme-img">
          </div>
        </span>
      `;
    }).join('');
  }

  renderOptionsHeadingByIndex({ optionsIndex }) {
    const { products } = this;
    const product = products.find((product) => {
      const { options: allOptions } = product;

      return !!allOptions[optionsIndex];
    });

    if (!product) return '';

    return product.options[optionsIndex].name;
  }

  renderOptionsByIndex({ product, optionsIndex }) {
    const { options: allOptions, variants: { edges: variants } } = product;
    const options = allOptions[optionsIndex];

    if (!options) return '';

    const { name, values } = options;
    const isColorType = name === 'Color';
    const wrapperClasses = isColorType ? 'product-block-options--swatch' : '';
    const method = isColorType ? 'renderSwatches' : 'renderOptions';

    return `
      <div class="product-block-options ${wrapperClasses}" data-option-name="${name}">
        <div class="product-block-options__inner">
          ${this[method]({ name, values, variants })}
        </div>
      </div>
    `;
  }

  renderMetafieldSubheading({ metafieldIdentifier }) {
    return metafieldIdentifier.label;
  }

  renderMetafieldData({ product, metafieldIdentifier }) {
    const metafield = product.metafields
      .filter((field) => (!!field))
      .find(({ namespace, key }) => (
        namespace === metafieldIdentifier.namespace && key == metafieldIdentifier.key
      ))
    ;

    if (!metafield) return '';

    const { type, value } = metafield;

    return type.includes('list') ? JSON.parse(value).map((val) => (`<p>${val}</p>`)).join('') : `<p>${value}</p>`;
  }

  renderRow(callback, args) {
    const { products } = this;

    const row = products.map((product) => {
      return `
        <div class="compare-page__cell">
          ${callback.call(this, { product, ...args })}
        </div>
      `;
    }).join('');

    return `<div class="compare-page__row">${row}</div>`;
  }

  renderHeading(heading) {
    return `
      <div class="compare-page__header">
        <i class="compare-page__heading h3">
          ${heading}
        </i>
      </div>
    `;
  }

  renderSubheading(subheading) {
    return `
      <div class="compare-page__subheading h5">
        ${subheading}
      </div>
    `;
  }

  getQuery() {
    return `
      query productByHandle($handle: String!, $metafieldIdentifiers: [HasMetafieldsIdentifier!]!) {
        product(handle: $handle) {
          id
          title
          handle
          vendor
          featuredImage {
            url
            altText
          }
          priceRange {
            minVariantPrice {
              amount
            }
            maxVariantPrice {
              amount
            }
          }
          options(first: 3) {
            name
            values
          }
          variants(first: 250) {
            edges {
              node {
                title
                availableForSale
                selectedOptions {
                  name
                  value
                }
                price {
                  amount
                }
                compareAtPrice {
                  amount
                }
                image {
                  url
                  altText
                }
              }
            }
          }
          metafields(identifiers: $metafieldIdentifiers) {
            type
            namespace
            key
            value
          }
        }
      }
    `;
  }

  async getProductData({ handle }) {
    const { storefront_api_key, storefront_api_ver } = window.theme.settings;
    const url = `https://fit2runecom.myshopify.com/api/${storefront_api_ver}/graphql.json`;
    const method = 'POST';
    const headers = {
      'Content-Type': 'application/json',
      'X-Shopify-Storefront-Access-Token': storefront_api_key,
    };
    const query = this.getQuery();
    const variables = {
      handle,
      metafieldIdentifiers: [
        ...this.metafieldIdentifiers.map(({ namespace, key }) => ({ namespace, key })),
        {
          namespace: 'custom',
          key: 'gender'
        },
      ]
    };

    try {
      const response = await fetch(url, {
        method,
        headers,
        body: JSON.stringify({
          query,
          variables,
        }),
      });
      const { data } = await response.json();

      return data;
    } catch (error) {
      return { product: null };
    }
  }

  refreshYotpoWidgets() {
    try {
      window.yotpoWidgetsContainer?.initWidgets(true);
    } catch (err) {
      console.log('Yotpo refresh failed');
    }
  }

  async init() {
    const { $compareList, items } = this;
    const unfilteredProducts = await Promise
      .all(items.map(async (item) => {
        const { product } = await this.getProductData(item);

        return product;
      }))
    ;
    const products = unfilteredProducts.filter((product) => !!product);

    if (!products.length) return;

    this.products = products;

    this.dataset.productsCount = products.length;

    $compareList.innerHTML = `
      ${this.renderRow(this.renderProductImage)}
      ${this.renderRow(this.renderProductGender)}
      ${this.renderRow(this.renderProductTitle)}
      ${this.renderRow(this.renderYotpoRatingsWidget)}
      ${this.renderRow(this.renderProductPrice)}
      ${this.renderRow(this.renderViewBtn)}
      ${this.renderHeading(window.comparePageTranslations.general)}
      ${this.renderSubheading(window.comparePageTranslations.brand)}
      ${this.renderRow(this.renderOptionsVendor)}
      ${this.renderSubheading(this.renderOptionsHeadingByIndex({ optionsIndex: 0 }))}
      ${this.renderRow(this.renderOptionsByIndex, { optionsIndex: 0 })}
      ${this.renderSubheading(this.renderOptionsHeadingByIndex({ optionsIndex: 1 }))}
      ${this.renderRow(this.renderOptionsByIndex, { optionsIndex: 1 })}
      ${this.renderSubheading(this.renderOptionsHeadingByIndex({ optionsIndex: 2 }))}
      ${this.renderRow(this.renderOptionsByIndex, { optionsIndex: 2 })}
      ${this.renderHeading(window.comparePageTranslations.details)}
      ${this.metafieldIdentifiers.map((metafieldIdentifier) => {
        const metafieldDataExists = this.products.find((product) => (product.metafields
          .filter((field) => (!!field))
          .find(({ namespace, key }) => (
            namespace === metafieldIdentifier.namespace && key == metafieldIdentifier.key
          ))
        ));

        return metafieldDataExists ? `
          ${this.renderSubheading(this.renderMetafieldSubheading({ metafieldIdentifier }))}
          ${this.renderRow(this.renderMetafieldData, { metafieldIdentifier })}
        ` : '';
      }).join('')}
    `;

    this.refreshYotpoWidgets();
  }

  removeTarget(targetId) {
    const { $compareList, $clearAllBtn } = this;
    const $clearTargetBtns = this.querySelectorAll('.js-clear-target-btn');

    $clearTargetBtns.forEach(($btn) => {
      $btn.style.pointerEvents = 'none';
      $btn.style.userSelect = 'none';
      $btn.setAttribute('disabled', true);
    });
    $clearAllBtn.style.pointerEvents = 'none';
    $clearAllBtn.style.userSelect = 'none';
    $clearAllBtn.setAttribute('disabled', true);

    if (targetId === 'all') {
      this.items = [];
      this.products = [];
      $compareList.innerHTML = `
        <div class="preloader-wrapper">
          <div class="loader"></div>
        </div>
      `;
      sessionStorage.setItem('compare-products', '[]');
    } else {
      const itemIndex = this.items.findIndex(({ id }) => {
        return id === targetId.replace('gid://shopify/Product/', '');
      });
      const productIndex = this.products.findIndex(({ id }) => {
        return id === targetId;
      });

      this.items.splice(itemIndex, 1);
      this.products.splice(productIndex, 1);
      sessionStorage['compare-products'] = JSON.stringify(this.items);
      sessionStorage['compare-products'] === '[]' ? $compareList.innerHTML = `
        <div class="preloader-wrapper">
          <div class="loader"></div>
        </div>
      ` : this.init();
    }

    $clearTargetBtns.forEach(($btn) => {
      $btn.style.pointerEvents = '';
      $btn.style.userSelect = '';
      $btn.removeAttribute('disabled');
    });
    $clearAllBtn.style.pointerEvents = '';
    $clearAllBtn.style.userSelect = '';
    $clearAllBtn.removeAttribute('disabled');
  }

  eventHandlers() {
    const { $backBtn, $clearAllBtn } = this;

    $backBtn.addEventListener('click', () => (history.go(-1)));
    $clearAllBtn.addEventListener('click', () => (this.removeTarget('all')));
    this.addEventListener('click', (event) => {
      const { target } = event;

      if (!target.classList.contains('js-clear-target-btn')) return;

      this.removeTarget(target.dataset.targetId);
    });
  }
}

customElements.get('compare-page') || customElements.define('compare-page', ComparePage);
