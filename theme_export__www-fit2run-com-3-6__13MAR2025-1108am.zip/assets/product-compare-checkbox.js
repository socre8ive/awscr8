class ProductCompareCheckbox extends HTMLElement {
  constructor() {
    super();
  }
  connectedCallback() {
    this.getInitialState();

    // do this to force the browser to refresh the checkbox
    window.addEventListener('pageshow', this.getInitialState.bind(this));

    // checkbox toggle
    this.addEventListener('change', (event) => {
      const { target: { checked, dataset } } = event;

      window.dispatchEvent(new CustomEvent('toggle-compare-product', {
        detail: {
          state: checked,
          targetId: dataset?.productId,
          targetHandle: dataset?.handle,
          thumb: dataset?.thumb,
        }
      }));
    });
  }

  getInitialState() {
    const checkboxId = this.dataset?.productId;
    const earlierSelectedProducts = sessionStorage.getItem('compare-products');

    if (!checkboxId || !earlierSelectedProducts) return;

    const parsedProducts = JSON.parse(earlierSelectedProducts);

    if (!parsedProducts.length) {
      this.checked = false;
      return;
    }

    const isMatch = parsedProducts.find(({ id }) => id === checkboxId);

    this.checked = !!isMatch;
  }
}

customElements.get('product-compare-checkbox') || customElements.define('product-compare-checkbox', ProductCompareCheckbox);
