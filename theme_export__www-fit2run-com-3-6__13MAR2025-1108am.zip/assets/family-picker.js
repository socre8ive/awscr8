if (!customElements.get("family-picker")) {
  class FamilyPicker extends HTMLElement {
    constructor() {
      super();
      this.mainOptionContainer = this.querySelector(".option-selector");
      this.sectionId = this.dataset.sectionId;
      this.sectionSelector = `#shopify-section-${this.sectionId}`;
    }
    addLoading() {
      document.body.classList.add('product-options-loading')
    }
    removeLoading() {
      document.body.classList.remove('product-options-loading')
    }
    updateUrl(newUrl) {
      if (!newUrl || this.dataset.updateUrl === "false") return;
      window.history.replaceState({}, "", newUrl);
    }
    rerenderSection(url) {
      this.addLoading();
      const currentSection = document.querySelector(this.sectionSelector);

      fetch(`${url}?section_id=${this.sectionId}`)
        .then((response) => {
          if (!response.ok) {
            this.removeLoading();
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.text();
        })
        .then((response) => {
          const parser = new DOMParser();
          const newSection = parser.parseFromString(response, "text/html").querySelector(this.sectionSelector);
          const newProductUrl = newSection.querySelector("family-picker")?.dataset?.currentProductUrl;
          currentSection.replaceWith(newSection);
          this.updateUrl(newProductUrl);
          this.removeLoading();
        });
    }
    handleContainerClick(e) {
      if (
        e.target.classList.contains("family-picker__dropdown") ||
        e.target.classList.contains("family-picker__opt-btn")
      ) {
        if (!e.target.dataset.productUrl) return;
        // prevent fetch current product and re-render section
        if (e.target.dataset.productUrl === this.dataset.currentProductUrl) return;
        this.rerenderSection(e.target.dataset.productUrl);
      }
    }
    bindListeners() {
      this.mainOptionContainer.addEventListener("click", this.handleContainerClick.bind(this));
    }
    init() {
      this.bindListeners();
    }
    connectedCallback() {
      this.init();
    }
  }

  customElements.define("family-picker", FamilyPicker);
}
