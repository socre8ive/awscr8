/**
 * Dependencies:
 * - Custom select component
 *
 * Required translation strings:
 * - addToCart
 * - noStock
 * - noVariant
 * - onlyXLeft
 */

class VariantPicker extends HTMLElement {
  constructor() {
    super();
    this.section = this.closest('.js-product');
    this.productForm = this.section.querySelector('.js-product-form');
    this.optionSelectors = this.querySelectorAll('.option-selector:not(.option-selector--custom)');
    this.colorOptionPosition = this.querySelector('[data-option="color"].option-selector:not(.option-selector--custom)')?.getAttribute('data-option-position');
    this.nativeSelector = document.getElementById(`variants-${this.section.dataset.section}`);
    this.markersLegends = document.querySelectorAll('.opt-label__markers-legend');
    this.familyPicker = document.querySelector('family-picker');
    this.data = this.getVariantData();
    this.selectedOptions = this.getSelectedOptions();
    this.variant = this.getSelectedVariant();
    this.markersCount = 0;
    this.updateGiftCardForm();
    this.updateAvailability();
    this.updateAddToCartButton();
    this.addEventListener('change', this.handleVariantChange.bind(this));
    this.applySearchParams();
    this.updateVariantsBasedonCookie();

    const currentVariantID = window.location.search.split('variant=')[1];
    this.badgesLogic(false, this.data.variants.filter(variant => variant.id === Number(currentVariantID))[0]);

    this.setAttribute('loaded', '');
  }

  /**
   * Handles 'change' events on the variant picker element.
   * @param {object} evt - Event object.
   */
  handleVariantChange(evt) {
    this.selectedOptions = this.getSelectedOptions();
    this.variant = this.getSelectedVariant();
    this.resetBadges();

    if (this.data.hasOwnProperty('family_products')) {
      this.badgesLogic(true);
    } else {
      this.badgesLogic();
    }

    this.preSelection = !this.variant && this.selectedOptions.find((o) => o === null) === null;

    this.updateUrl(evt);
    this.updateVariantInput();
    this.updateAddToCartButton();
    this.updateAvailability();
    this.updatePrice();
    this.updateBackorderText();
    this.updatePickupAvailability();
    this.updateSku();
    this.updateBarcode();
    this.updateGiftCardForm();
    this.updateModelInfo();
    this.updateCookies();
    VariantPicker.updateLabelText(evt);
    !this.variant && this.updateExistedOption(evt)

    this.dispatchEvent(new CustomEvent('on:variant:change', {
      bubbles: true,
      detail: {
        form: this.productForm,
        variant: this.variant,
        allVariants: this.data.variants,
        selectedOptions: this.selectedOptions
      }
    }));
  }

  badgesLogic(isFamily = false, variant = this.variant) {
    const currentOptionsWithoutColor = variant.options.filter((option, index) => index !== this.colorOptionPosition - 1).join(' / ');
    const familySwatches = document.querySelectorAll('family-picker .js-option-color');
    this.markersCount = 0;

    if (isFamily) {
      familySwatches?.forEach(familySwatch => {
        const familyProductId = familySwatch.dataset.productId;
        const familyProductColorPosition = familySwatch.dataset.colorPosition;

        this.showBadges(currentOptionsWithoutColor, this.data.family_products[familyProductId], familyProductColorPosition);
      });
    } else {
      this.showBadges(currentOptionsWithoutColor);
    }

    this.toggleMarkersLegend();
  }

  showBadges(currentOptionsWithoutColor, primaryData = this.data, colorPosition = this.colorOptionPosition - 1) {
    const specialVariants = primaryData.variants.filter(variant =>  variant.title.replaceAll(` / ${variant.options[colorPosition]}`, '').replaceAll(`${variant.options[colorPosition]} / `, '').trim() === currentOptionsWithoutColor);

    specialVariants.map(variant => {
      const colorMarkerValue = primaryData.formatted[variant.id].colorMarkers;

      if (colorMarkerValue !== undefined) {
        this.markersCount++;
        const colorSwatch = document.querySelector(`[value="${variant.options[colorPosition]}"].js-option-color`);
        const saleMarker = colorSwatch.nextElementSibling.querySelector('.opt-label__marker--sale');
        const limitedMarker = colorSwatch.nextElementSibling.querySelector('.opt-label__marker--limited');

        if (colorMarkerValue.includes(window.theme.strings.colorMarkers.sale) && saleMarker) saleMarker.classList.add('is-active');
        if (colorMarkerValue.includes(window.theme.strings.colorMarkers.limited) && limitedMarker) limitedMarker.classList.add('is-active');
      }
    });
  }

  toggleMarkersLegend() {
    this.markersLegends.forEach(legend => {
      legend.classList.toggle('hidden', this.markersCount === 0);
    });
  }

  resetBadges() {
    const colorMarkers = document.querySelectorAll('.opt-label__marker.is-active');

    colorMarkers.forEach(marker => {
      marker.classList.remove('is-active');
    });
  }

  /**
   * Updates the "Add to Cart" button label and status.
   */
  updateModelInfo() {
    if (!this.variant) return;

    const { modelInfo } = this.data.formatted[this.variant.id];
    const modelInfoContainer = document.querySelector('.model-information');
    const modelInfoDescr = document.querySelector('.model-information__description');

    if (modelInfoContainer) {
      modelInfoContainer.classList.toggle('active', !!modelInfo);
      modelInfoDescr.textContent = modelInfo ? modelInfo : '';
    }
  }

  updateExistedOption(evt) {
    const selectedNonexistentOption = this.querySelector(`input[type="radio"]:not([name="${evt.target.name}"]):checked`);

    if (!selectedNonexistentOption) return;

    const optionsWrapper = selectedNonexistentOption.parentElement;

    optionsWrapper.querySelector('input[type="radio"]:not(.is-nonexistent)').click();
  }

  updateGiftCardForm() {
    const isGiftCard = this.section.classList.contains('gift-card-product');
    if (!isGiftCard) return;
    const recipientForm = document.querySelector('gift-card-recipient');
    const recipientFormCheckbox = recipientForm.querySelector('.gift-card-recipient__checkbox');
    let activeGiftCardType = this.variant.option1;
    const params = new URL(document.location).searchParams;
    const variantIdFromSearchParams = params.get('variant');

    if (variantIdFromSearchParams) {
      const activeVariant = this.data.variants.find(variant => variant.id === Number(variantIdFromSearchParams));
      activeGiftCardType = activeVariant.option1;
    }
    const isVirtualGiftCard = activeGiftCardType === 'Virtual' && !recipientFormCheckbox.checked;
    const isRegularGiftCard = activeGiftCardType === "Regular" && recipientFormCheckbox.checked;

    isVirtualGiftCard && recipientFormCheckbox.click();
    isRegularGiftCard && recipientFormCheckbox.click();
  }

  setKlaviyoCTA() {
    this.addBtn.insertAdjacentHTML('afterend', `
      <a href="#"
        class="btn klaviyo-bis-trigger"
        style="text-align: center; margin: 0px; width: auto;"
        data-uw-rm-brl="PR">
        Sold Out - Notifiy Me When It's Available
      </a>
    `);
  }

  getKlaviyoCTA() {
    const $klaviyoBISTrigger = this.addBtn?.parentElement?.querySelector('.klaviyo-bis-trigger');

    return $klaviyoBISTrigger;
  }

  atcUnavailable() {
    const unavailableStr = this.variant ? theme.strings.noStock : theme.strings.noVariant;
    const $klaviyoBISTrigger = this.getKlaviyoCTA();

    if(theme.template.includes("product") ) {
      if (this.variant) {
        if (!$klaviyoBISTrigger) this.setKlaviyoCTA();
        setTimeout(() => {
          this.addBtn.style.display = 'none';
        }, "200");
        setTimeout(() => {
          this.addBtn.parentElement.querySelector('.klaviyo-bis-trigger').style.display = 'block';
        }, "600");
      } else {
        if ($klaviyoBISTrigger) $klaviyoBISTrigger.remove();
        setTimeout(() => {
          this.addBtn.style.display = '';
        }, "200");
      }
    }

    this.addBtn.textContent = unavailableStr;
    this.addBtn.disabled = true;
  }

  atcAvailable() {
    const $klaviyoBISTrigger = this.getKlaviyoCTA();

    if ($klaviyoBISTrigger) $klaviyoBISTrigger.remove();
    this.addBtn.style.display = '';
    this.addBtn.textContent = this.addBtn.dataset.addToCartText;
    this.addBtn.disabled = false;
  }

  updateAddToCartButton() {
    if (!this.productForm) return;
    if (this.selectedOptions.indexOf(null) > -1) return;

    this.addBtn = this.addBtn || this.productForm.querySelector('[name="add"]');

    const variantAvailable = this.variant && this.variant.available && this.data.formatted[this.variant.id].disable_online != 'true';

    variantAvailable ? this.atcAvailable() : this.atcUnavailable();
  }

  /**
   * Updates the availability status of an option.
   * @param {Element} optionEl - Option element.
   * @param {boolean} exists - Does this option lead to a variant that exists?
   * @param {boolean} available - Does this option lead to a variant that is available to buy?
   */
  static updateOptionAvailability(optionEl, exists, available, isHidden = false ) {
    const el = optionEl;
    const unavailableText = exists ? theme.strings.noStock : theme.strings.noVariant;
    el.classList.toggle('is-unavailable', !available);
    el.classList.toggle('is-nonexistent', !exists);

    el.classList.remove('is-hidden');
    if(isHidden && (el.name.includes('size-option') || el.name.includes('width-option') )) {
      el.classList.add('is-hidden');
    }

    if (optionEl.classList.contains('custom-select__option')) {
      const em = el.querySelector('em');

      if (em) {
        em.hidden = available;
      }

      if (!available) {
        if (em) {
          em.textContent = unavailableText;
        } else {
          el.innerHTML = `${el.innerHTML} <em class="pointer-events-none">${unavailableText}</em>`;
        }
      }
    } else if (!available) {
      el.nextElementSibling.title = unavailableText;
    } else {
      el.nextElementSibling.removeAttribute('title');
    }
  }

  /**
   * Updates the availability status in option selectors.
   */
  updateAvailability() {
    if (this.dataset.showAvailability === 'false') return;
    const { availabilityMode } = this.dataset; // 'down' or 'selection'
    let currVariant = this.variant;

    if (!this.variant) {
      currVariant = { options: this.selectedOptions };
    }

    if (availabilityMode === 'selection') {
      // Flag all options as unavailable
      this.querySelectorAll('.js-option').forEach((optionEl) => {
        VariantPicker.updateOptionAvailability(optionEl, false, false);
      });

      // Flag selector options as available or sold out, depending on the variant availability
      this.optionSelectors.forEach((selector, selectorIndex) => {
        this.data.variants.forEach((variant) => {
          let matchCount = 0;

          variant.options.forEach((option, optionIndex) => {
            if (option === currVariant.options[optionIndex] && optionIndex !== selectorIndex) {
              matchCount += 1;
            }
          });

          if (matchCount === currVariant.options.length - 1) {
            const options = selector.querySelectorAll('.js-option');
            const optionEl = Array.from(options).find((opt) => {
              if (selector.dataset.selectorType === 'dropdown') {
                return opt.dataset.value === variant.options[selectorIndex];
              }
              return opt.value === variant.options[selectorIndex];
            });

            if (optionEl) {
              VariantPicker.updateOptionAvailability(optionEl, true, variant.available);
            }
          }
        });
      });
    } else {
      this.optionSelectors.forEach((selector, selectorIndex) => {
        const options = selector.querySelectorAll('.js-option:not([data-value=""])');
        options.forEach((option) => {
          const optionValue = selector.dataset.selectorType === 'dropdown' ? option.dataset.value : option.value;
          // any available variants with previous options and this one locked in?
          let variantsExist = false;
          let variantsAvailable = false;
          let wholeOptionsHidden = false;
          let variantsHidden = [];
          this.data.variants.forEach((v) => {

            let matches = 0;
            for (let i = 0; i < selectorIndex; i += 1) {
              if (v.options[i] === this.selectedOptions[i] || this.selectedOptions[i] === null) {
                matches += 1;
              }
            }
            if (v.options[selectorIndex] === optionValue && matches === selectorIndex) {
              variantsExist = true;
              if (v.available) {
                variantsAvailable = true;
              }

              if (this.data.formatted[v.id].disable_online != 'true') {
                variantsHidden.push('false');
              } else {
                variantsHidden.push('true');
              }
            }
          });

          if (variantsHidden.length > 0) {
            if (variantsHidden.every(variantHidden => variantHidden === 'true')) {
              wholeOptionsHidden = true;
            }
          }
          VariantPicker.updateOptionAvailability(option, variantsExist, variantsAvailable, wholeOptionsHidden);
        });
      });
    }
  }

  /**
   * Updates the backorder text and visibility.
   */
  updateBackorderText() {
    this.backorder = this.backorder || this.section.querySelector('.backorder');
    if (!this.backorder) return;

    let hideBackorder = true;

    if (this.variant && this.variant.available) {
      const { inventory } = this.data.formatted[this.variant.id];

      if (this.variant.inventory_management && inventory === 'none') {
        const backorderProdEl = this.backorder.querySelector('.backorder__product');
        const prodTitleEl = this.section.querySelector('.product-title');
        const variantTitle = this.variant.title.includes('Default') ? '' : ` - ${this.variant.title}`;

        backorderProdEl.textContent = `${prodTitleEl.textContent}${variantTitle}`;
        hideBackorder = false;
      }
    }

    this.backorder.hidden = hideBackorder;
  }

  /**
   * Updates the colour option label text.
   * @param {object} evt - Event object
   */
  static updateLabelText(evt) {
    if (!evt.target) return;

    const selector = evt.target.closest('.option-selector');

    if (selector.dataset.selectorType === 'dropdown') return;

    const colorText = selector.querySelector('.js-color-text');

    if (!colorText) return;

    colorText.textContent = evt.target.nextElementSibling.querySelector('.js-value').textContent;
  }

  /**
   * Updates the pick up availability.
   */
  updatePickupAvailability() {
    this.pickUpAvailability = this.pickUpAvailability || this.section.querySelector('pickup-availability');
    if (!this.pickUpAvailability) return;

    if (this.variant && this.variant.available) {
      this.pickUpAvailability.getAvailability(this.variant.id);
    } else {
      this.pickUpAvailability.removeAttribute('available');
      this.pickUpAvailability.innerHTML = '';
    }
  }

  /**
   * Updates the price.
   */
  updatePrice() {
    this.price = this.price || this.section.querySelector('.product-price .price');
    this.clubPrice = this.clubPrice || this.section.querySelector('.product-price .price--club-pdp');
    if (!this.price) return;

    let { variant } = this;
    if (this.preSelection) {
      variant = this.data.variants[0];
      for (let i = 1; i < this.data.variants.length; i += 1) {
        if (this.data.variants[i].price < variant.price) variant = this.data.variants[i];
      }
    }

    if (variant) {
      const priceCurrentEl = this.price.querySelector('.price__current');
      const priceWasEl = this.price.querySelector('.price__was');
      const unitPriceEl = this.price.querySelector('.unit-price');
      const currentVariantPrice = this.data.variants.find(el => el.id === variant.id).price
      // Update current price and original price if on sale.
      priceCurrentEl.innerHTML = this.data.formatted[variant.id].price;
      if (this.clubPrice) {
        const variantSale = this.data.formatted[variant.id].variantSale
        const isvariantSale = variantSale === 'Markdown'
        this.clubPrice.classList.toggle('active', !isvariantSale)

        const clubPrice = this.clubPrice.querySelector('.club-price')
        const clubDiscount = 1 - (window.theme.settings.clubPriceDiscount / 100)
        const updatedClubPrice = currentVariantPrice * clubDiscount / 100
        const formettedClubPrice = updatedClubPrice.toFixed(2)
        clubPrice.innerHTML = `${window.theme.currencySign}${formettedClubPrice}`
      }
      if (priceWasEl) priceWasEl.innerHTML = this.data.formatted[variant.id].compareAtPrice || '';

      // Update unit price, if specified.
      if (variant.unit_price_measurement) {
        const valueEl = this.price.querySelector('.unit-price__price');
        const unitEl = this.price.querySelector('.unit-price__unit');
        const value = variant.unit_price_measurement.reference_value;
        const unit = variant.unit_price_measurement.reference_unit;

        valueEl.innerHTML = this.data.formatted[variant.id].unitPrice;
        unitEl.textContent = value === 1 ? unit : `${value} ${unit}`;
        unitPriceEl.hidden = false;
      } else if (unitPriceEl) {
        unitPriceEl.hidden = true;
      }

      this.price.classList.toggle('price--on-sale', variant.compare_at_price > variant.price);
      this.price.classList.toggle('price--sold-out', !variant.available && !this.preSelection);
    }

    this.price.querySelector('.price__default').hidden = !this.variant && !this.preSelection;
    this.price.querySelector('.price__no-variant').hidden = this.variant || this.preSelection;
    const from = this.price.querySelector('.price__from');
    if (from) {
      from.hidden = !this.preSelection;
    }
  }

  /**
   * Updates the SKU.
   */
  updateSku() {
    this.sku = this.sku || this.section.querySelector('.product-sku__value');
    if (!this.sku) return;

    const skuAvailable = this.variant && this.variant.sku;
    this.sku.textContent = skuAvailable ? this.variant.sku : '';
    this.sku.parentNode.hidden = !skuAvailable;
  }

  /**
   * Updates the Barcode.
   */
  updateBarcode() {
    this.barcode = this.barcode || this.section.querySelector('.product-barcode__value');
    if (!this.barcode) return;

    const barcodeAvailable = this.variant && this.variant.barcode;
    this.barcode.textContent = barcodeAvailable ? this.variant.barcode : '';
    this.barcode.parentNode.hidden = !barcodeAvailable;
  }

  /**
   * Updates the url with the selected variant id.
   * @param {object} evt - Event object.
   */
  updateUrl(evt) {
    if (!evt || evt.type !== 'change' || this.dataset.updateUrl === 'false') return;
    const url = this.variant ? `${this.dataset.url}?variant=${this.variant.id}` : this.dataset.url;
    window.history.replaceState({ }, '', url);
  }

  /**
   * Updates the value of the hidden [name="id"] form inputs.
   */
  updateVariantInput() {
    this.forms = this.forms || this.section.querySelectorAll('.js-product-form, .js-instalments-form');

    this.forms.forEach((form) => {
      const input = form.querySelector('[name="id"]');
      input.value = this.variant ? this.variant.id : '';
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  updateCookies() {
    var productFamilyNameDiv = document.querySelector('#productFamily-name');
    if (productFamilyNameDiv) {
      var productFamilyName = productFamilyNameDiv.dataset.familyName;
      var productFormId = document.querySelector('#productFamily-name').dataset.formId;
      var selectedWidth = 0;
      selectedWidth = document.querySelector('input[name="'+productFormId+'-width-option"]:checked').value;
      var selectedSize = 0;
      selectedSize = document.querySelector('input[name="'+productFormId+'-size-option"]:checked').value;
      this.setCookie(productFamilyName, selectedWidth+'|'+selectedSize, 30);
    }
  }

  /**
   * Gets the variant data for a product.
   * @returns {?object}
   */
  getVariantData() {
    const dataEl = this.querySelector('[type="application/json"]');
    return JSON.parse(dataEl.textContent);
  }

  /**
   * Get the selected values from a list of variant options.
   * @returns {Array} Array of selected option values, value is null if not selected.
   */
  getSelectedOptions() {
    const selectedOptions = [];

    this.optionSelectors.forEach((selector) => {
      if (selector.dataset.selectorType === 'dropdown') {
        const selected = selector.querySelector('.custom-select__option[aria-selected="true"]');
        selectedOptions.push(selected && selected.dataset.value !== '' ? selected.dataset.value : null);
      } else {
        const selected = selector.querySelector('input:checked');
        selectedOptions.push(selected ? selected.value : null);
      }
    });

    return selectedOptions;
  }

  /**
   * Check width and size from cookies and set value if available
   */
  updateVariantsBasedonCookie() {
    var productFamilyNameDiv = document.querySelector('#productFamily-name');
    if (productFamilyNameDiv) {
      var productFamilyName = productFamilyNameDiv.dataset.familyName;
      var productFormId = document.querySelector('#productFamily-name').dataset.formId;
      var productCookie = this.getCookie(productFamilyName);
      const allParam = productCookie.split("|");

      this.optionSelectors.forEach((selector) => {
        const mainOption = selector.querySelector('.label').innerHTML;
        if(mainOption == 'Width') {
          const allWidths = selector.querySelectorAll('input');
          allWidths.forEach((curWidth) => {
            if(curWidth.value == allParam[0] && !curWidth.classList.contains("is-unavailable")) {
              curWidth.checked = true;
            }
          });
        }
        if(mainOption == 'Size') {
          const allSizes = selector.querySelectorAll('input');
          allSizes.forEach((curSize) => {
            if(curSize.value == allParam[1] && !curSize.classList.contains("is-unavailable")) {
              curSize.checked = true;
            }
          });
        }
      });

      this.handleVariantChange(this);
    }
  }

  /**
   * Get selected variant data.
   * @returns {?object} Variant object, or null if one is not selected.
   */
  getSelectedVariant() {
    return this.data.variants.find(
      (v) => v.options.every((val, index) => val === this.selectedOptions[index])
    );
  }

  /**
   * Apply search parameters.
   */
  applySearchParams() {
    const searchParams = new URLSearchParams(window.location.search);

    Array.from(searchParams.keys()).forEach((key) => {
      const value = searchParams.get(key);
      const optionSelectors = Array.from(this.optionSelectors);
      const matchingOptionSelector = optionSelectors.find((x) => x.dataset.option === key);
      if (!matchingOptionSelector) return;

      if (matchingOptionSelector.dataset.selectorType === 'dropdown') {
        const colorOptionDropdown = matchingOptionSelector.querySelector(`.custom-select__option[data-value="${value}"]`);
        if (colorOptionDropdown) {
          const customSelect = colorOptionDropdown.closest('custom-select');
          customSelect.selectOption(colorOptionDropdown);
        }
      } else {
        const matchingInput = matchingOptionSelector.querySelector(`input[value="${value}"]`);
        if (matchingInput) {
          const matchingOptionValue = matchingOptionSelector.querySelector('.option-selector__label-value');
          if (matchingOptionValue) {
            matchingOptionSelector.querySelector('.option-selector__label-value').textContent = value;
          }
          matchingInput.checked = true;
          matchingInput.dispatchEvent(
            new CustomEvent('change', { bubbles: true, cancelable: false })
          );
        }
      }
    });
  }
}

customElements.get('variant-picker') || customElements.define('variant-picker', VariantPicker);
