if (!customElements.get("gender-picker")) {
  class GenderPicker extends HTMLElement {
    constructor() {
      super();
      this.sectionStyleName = this.dataset.styleName;
      this.productHandle = this.dataset.productHandle;
      this.init();
    }

    showOrHide (gender) {
      let normalizedGender = gender.toLowerCase().replace(/[\s~`!@#$%^&*(){}\[\];:"'<,.>?\/\\|_+=-]/g, '');

      return (normalizedGender === 'mens' || normalizedGender === 'womens');
    }

    async renderGenderOptions () {
      const productResults = await this.getGenderProducts()
      if (!productResults) return
      const genderProducts = productResults.data.search.edges
      if (genderProducts.length <= 1) return
      genderProducts.forEach(product => {
        const { handle } = product.node
        const { totalInventory } = product.node
        const { onlineStoreUrl } = product.node
        const { value } = product.node.metafield
        const { rootUrl } = window.theme.routes

        if(onlineStoreUrl != null) {
          if(this.showOrHide(value)) {
            const activeOptionClass = this.productHandle === handle ? 'active' : ''
            const genderOptionMarkup = `
              <a href="${rootUrl}products/${handle}" class="${activeOptionClass} gender-option-label opt-label">${value}</a>
            `
            const parser = new DOMParser();
            const fragment = new DocumentFragment();
            const genderOptionEl = parser
            .parseFromString(genderOptionMarkup, 'text/html').querySelector('.gender-option-label')
            fragment.appendChild(genderOptionEl);
            this.appendChild(fragment)
          }
        }
      })
    }

    async getGenderProducts() {
      if (!this.sectionStyleName) return;
      try {
        const query = '';
        const first = 50;
        const productFilters = [
          {
            "productMetafield": {
              "namespace": "custom",
              "key": "style_name",
              "value": this.sectionStyleName
            }
          }
        ]
        const { storefront_api_key, storefront_api_ver } = window.theme.settings
        const response = await fetch(`https://fit2runecom.myshopify.com/api/${storefront_api_ver}/graphql.json`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Shopify-Storefront-Access-Token': storefront_api_key,
          },
          body: JSON.stringify({
            query: `query searchProducts($query: String!, $productFilters: [ProductFilter!]!, $first: Int) {
              search(query: $query, productFilters: $productFilters, first: $first, types: PRODUCT) {
                edges {
                  node {
                    ... on Product {
                      id
                      title
                      handle
                      totalInventory
                      onlineStoreUrl
                      metafield(namespace: "custom", key: "gender") {
                        value
                      }
                    }
                  }
                }
              }
            }`,
            variables: { query, productFilters, first }
          })
        });
        const json = await response.json();
        return json;
      } catch (error) {
        console.error(error);
      }
    }

    async init() {
      await this.renderGenderOptions()
    }
  }

  customElements.define("gender-picker", GenderPicker);
}
