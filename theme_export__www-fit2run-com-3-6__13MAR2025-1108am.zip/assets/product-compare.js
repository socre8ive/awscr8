class ProductCompare extends HTMLElement {
  constructor() {
    super();

    this.slotLength = 4;
    this.thumbsContainer = this.querySelector(".product-compare__thumbs");
    this.handleToggleCompare = this.handleToggleCompare.bind(this);
  }
  connectedCallback() {
    this.init();
  }
  createSlots(quantity) {
    if (!quantity) return;
    const fragment = new DocumentFragment();
    for (let index = 0; index < quantity; index++) {
      const li = document.createElement("li");
      li.classList.add("product-compare__thumb");
      fragment.appendChild(li);
    }
    return fragment;
  }

  renderThumbs(rawElements) {
    const createCloseIcon = () => {
      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("width", "10");
      svg.setAttribute("height", "10");
      svg.setAttribute("viewBox", "0 0 10 10");
      svg.setAttribute("fill", "none");

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", "M1 1L9 9M1 9L9 1");
      path.setAttribute("stroke", "currentColor");
      path.setAttribute("stroke-width", "2");
      svg.appendChild(path);
      return svg;
    };
    const fragment = new DocumentFragment();

    if (!rawElements || !rawElements.length) {
      const slots = this.createSlots(4);
      fragment.appendChild(slots);
      this.thumbsContainer?.replaceChildren(fragment);
      return;
    }
    const emptySlotsCount = this.slotLength - rawElements.length;

    rawElements.forEach((el) => {
      const li = document.createElement("li");
      li.classList.add("product-compare__thumb");
      const removeButton = document.createElement("button");
      removeButton.setAttribute("type", "button");
      removeButton.setAttribute("data-target-id", el.id);
      removeButton.classList.add("product-compare__remove-btn");
      removeButton.appendChild(createCloseIcon());
      li.appendChild(removeButton);
      const img = document.createElement("img");
      const imgSrc = el.thumb ? el.thumb : window.theme.settings.defaultProductImage
      img.setAttribute("src", imgSrc);
      li.appendChild(img);
      fragment.appendChild(li);
    });

    if (emptySlotsCount > 0) {
      const slots = this.createSlots(emptySlotsCount);
      fragment.appendChild(slots);
    }
    this.thumbsContainer?.replaceChildren(fragment);
  }
  addProduct(e) {
    const { targetHandle, targetId, thumb } = e?.detail;
    const item = { id: targetId, handle: targetHandle, thumb };

    let compareProducts = [];

    const previousCompareProducts = sessionStorage.getItem("compare-products");

    if (previousCompareProducts) {
      compareProducts = JSON.parse(previousCompareProducts);
      if (!compareProducts.length) this.show();
    } else {
      this.show();
      compareProducts = [];
    }
    if (compareProducts.length <= 3) {
      compareProducts.push(item);
      sessionStorage.setItem("compare-products", JSON.stringify(compareProducts));
      this.renderThumbs(compareProducts);
    } else {
      this.uncheckCheckbox(compareProducts[0]?.id);
      compareProducts[0] = item;
      sessionStorage.setItem("compare-products", JSON.stringify(compareProducts));
      this.renderThumbs(compareProducts);
    }
  }

  removeProduct(targetId) {
    if (!targetId) return;
    const previousCompareProducts = sessionStorage.getItem("compare-products");
    if (!previousCompareProducts) return;
    const compareProducts = JSON.parse(previousCompareProducts).filter((e) => e.id !== targetId);
    sessionStorage.setItem("compare-products", JSON.stringify(compareProducts));
    this.renderThumbs(compareProducts);
    if (!compareProducts.length) {
      this.hide();
    }
  }
  removeAll() {
    const previousCompareProducts = sessionStorage.getItem("compare-products");
    if (!previousCompareProducts) return;
    const compareProducts = JSON.parse(previousCompareProducts);
    if (!compareProducts.length) return;
    const itemsToRemove = compareProducts.map(({ id }) => id);
    sessionStorage.setItem("compare-products", "[]");
    this.renderThumbs([]);
    this.hide();
    this.uncheckCheckbox(itemsToRemove);
  }

  handleToggleCompare(e) {
    e?.detail?.state === true ? this.addProduct(e) : this.removeProduct(e?.detail?.targetId);
  }
  hide() {
    this.classList.add("hidden");
  }
  show() {
    this.classList.remove("hidden");
  }

  uncheckCheckbox(target) {
    // use this to prevent dispatching events and use many event listeners at checkboxes
    if (!target) return;
    function findAndUncheck(productId) {
      const checkbox = document.querySelector(`input[data-product-id='${productId}']`);
      if (!checkbox) return;
      checkbox.checked = false;
    }
    if (typeof target === "string") {
      findAndUncheck(target);
    } else {
      if (!target.length) return;
      target.forEach((target) => {
        findAndUncheck(target);
      });
    }
  }

  firstRender() {
    const earlierSelectedProducts = sessionStorage.getItem("compare-products");
    if (!earlierSelectedProducts) return;
    const parsedProducts = JSON.parse(earlierSelectedProducts);
    if (!parsedProducts.length) return;
    this.renderThumbs(parsedProducts);
    this.show();
  }
  handleClick(e) {
    const removeButton = e.target.classList.contains("product-compare__remove-btn") ? e.target : null;
    const removeAllButton = e.target.classList.contains("product-compare__remove-all") ? e.target : null;

    if (removeButton) {
      this.removeProduct(removeButton.dataset?.targetId);
      this.uncheckCheckbox(removeButton.dataset?.targetId);
      return;
    }
    if (removeAllButton) {
      this.removeAll();
    }
  }
  bindEventListeners() {
    window.addEventListener("toggle-compare-product", this.handleToggleCompare);
    this.addEventListener("click", this.handleClick);
  }
  init() {
    this.bindEventListeners();
    this.firstRender();
  }
}

customElements.get("product-compare") || customElements.define("product-compare", ProductCompare);
